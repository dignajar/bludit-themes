# Changelog

## 0.1 - 2015-11-20
- Initial theme release. Hope it goes well!
