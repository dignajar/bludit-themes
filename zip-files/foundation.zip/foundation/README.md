Foundation
==========

_Theme based on Foundation for Sites 6_

The theme uses Foundation for Sites 6. For more information see http://foundation.zurb.com/sites.html.

Credits
-------

The original version of the theme was contributed by Frédéric K.

Versions
--------

6.2.4, November 28, 2016
- Update to Foundation 6.2.4.
- Minor fixes.
