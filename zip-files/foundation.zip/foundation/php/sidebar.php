<div class="sticky" data-sticky data-anchor="content">
	<!-- Plugins Sidebar -->
	<?php Theme::plugins('siteSidebar') ?>
</div>