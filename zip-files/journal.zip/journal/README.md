#Journal

Journal is a fast and minimalistic theme for [Bludit CMS](https://www.bludit.com/) based on the [Siimple CSS framework](https://github.com/siimple/siimple/).

Demo: [Click Here!](https://anaggh.net/blog/)
