[Bludit](http://www.bludit.com/) — "Barebones" Skeleton Theme
================================================

The goal of this theme is to provide a minimal starting structure for designers & developers. It is based on [Skeleton](http://getskeleton.com), a popular ultra-lightweight CSS library.

I intend for this theme to be as un-opinionated as possible, but a minimal CSS-based responsive navigation menu has been included. The initial structure is based on the Pure theme. 

Please let me know if you have feedback. Edits are welcome!

Thanks,
Jory Phillips
