<!-- Plugins Sidebar -->
<?php Theme::plugins('siteSidebar') ?>