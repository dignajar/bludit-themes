<div id="fh5co-content">
	<div class="container">
		<div class="row">
			<div class="col-md-10 col-md-offset-1">
				<div class="row">
					<div class="col-md-3 animate-box">
						<h3>Description</h3>
						<p><?php echo $Page->description() ?></p>
						<!--
						<ul class="fh5co-list-check">
							<li>Far far away</li>
							<li>The word mountains</li>
							<li>Far from the countries</li>
							<li>Bookmarksgrove right</li>
						</ul>
						-->
					</div>
					<div class="col-md-9">
					<?php echo $Page->content() ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>