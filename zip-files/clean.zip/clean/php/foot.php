<?php
	// Javascript files
	Theme::javascript(array(
		'modernizr-2.6.2.min.js',
		'jquery.easing.1.3.js',
		'bootstrap.min.js',
		'jquery.waypoints.min.js',
		'main.js'
	));
?>