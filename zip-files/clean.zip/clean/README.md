Theme name: Clean
Author: FREEHTML5.CO

Bludit dependencies:
- This theme is just for pages.
- Site title.
- Site description.
- Site slogan.
- Cover image on pages
- Pages with page break
- Pages with description