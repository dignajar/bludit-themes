<!-- Highlight.js -->
<script>hljs.initHighlightingOnLoad();</script>

<!-- Custom Fonts -->
<link href="https://fonts.googleapis.com/css?family=Lato:400,900" rel="stylesheet">

<!-- Custom Javascript -->
<script
			  src="//code.jquery.com/jquery-2.2.3.min.js"
			  integrity="sha256-a23g1Nt4dtEYOj7bR+vTu7+T8VP13humZFBJNIYoEJo="
			  crossorigin="anonymous">
</script>
