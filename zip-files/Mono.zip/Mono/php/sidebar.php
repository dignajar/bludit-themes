<header class="logo"><h1><?php echo $Site->title() ?></h1></header>
<nav role='navigation'>
  <?php Theme::plugins('siteSidebar') ?>
</nav>
