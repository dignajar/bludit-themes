<header class="logo"><a href="<?php echo $Site->url() ?>"><h1><?php echo $Site->title() ?></h1></a></header>
<nav role='navigation'>
  <?php Theme::plugins('siteSidebar') ?>
</nav>
