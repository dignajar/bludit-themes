<?php
$directory = ".";

require "scss.inc.php";
scss_server::serveFrom($directory);