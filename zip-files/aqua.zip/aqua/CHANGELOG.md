# Changelog

## Version 1.6.2
## 2017-07-16
- Tidy up HTML.
- Using Bludit version numbers.

## Version 1.1
## 2017-07-16
- Fixed CSS link. Added Cover Image.

## Version 1.0
## 2016-01-02
- Initial theme release. Future updates likely!
