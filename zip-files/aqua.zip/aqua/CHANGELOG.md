# Changelog

## Version 1.0
## 2016-01-02
- Initial theme release. Future updates likely!
