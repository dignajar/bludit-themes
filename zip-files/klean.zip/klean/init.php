<?php

define('PARENT_PAGES_LINK', false);

?>