Information for proper functionality with Bludit:

In the main-view, this theme shows the coverimage and title of every post.
After clicking one image, it zooms in and displays also the content of the post.
So be sure to set a coverimage to all posts (or it will look weird ;))

After clicking on "ABOUT" at the right bottom corner of the page,
this theme shows on the left (over social media links) title and content of page with 
position 1. On the right side there is page with position 2. All other positions 
will be ignored.

You also have to set the social-media links manually in the footer.php (or comment them out)

-----------------------------------------------------------------


Multiverse by HTML5 UP
html5up.net | @n33co
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)


Say hello to Multiverse, a slick, one-page gallery design with a fully functional lightbox
(courtesy of my Poptrox plugin for jQuery) and a custom, reusable "panel" system (click the
"About" button in the lower right to see what I mean). Had a ton of fun putting this one
together, and I hope you have as much fun working with it :)

Demo images* courtesy of Unsplash, a radtastic collection of CC0 (public domain) images
you can use for pretty much whatever.

(* = not included)

AJ
n33.co @n33co dribbble.com/n33


Credits:

	Demo Images:
		Unsplash (unsplash.com)

	Icons:
		Font Awesome (fortawesome.github.com/Font-Awesome)

	Other:
		jQuery (jquery.com)
		html5shiv.js (@afarkas @jdalton @jon_neal @rem)
		Misc. Sass functions (@HugoGiraudel)
		Respond.js (j.mp/respondjs)
		Skel (skel.io)