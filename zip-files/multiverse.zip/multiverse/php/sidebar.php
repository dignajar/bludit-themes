<h1><a href="<?php echo $Site->url(); ?>"><strong><?php echo $Site->title() ?></strong> <?php echo $Site->slogan() ?> </a></h1>
<nav>
	<ul>
		<li><a href="#footer" class="icon fa-info-circle">About</a></li>
	</ul>
</nav>
