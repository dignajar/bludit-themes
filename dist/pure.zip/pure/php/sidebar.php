<div class="sidebar-content">

<h1 class="title"><?php echo $Site->title() ?></h1>
<h2 class="slogan"><?php echo $Site->slogan() ?></h2>

<!-- Plugins Sidebar -->
<?php Theme::plugins('siteSidebar') ?>

</div>