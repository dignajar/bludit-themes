<section id="post">
<h2 class="post-title"><?php echo $Post->title() ?></h2>
<div class="post-content">
<?php echo $Post->content() ?>
</div>
</section>