Theme name: Future Imperfect
Author: HTML5 UP - html5up.net | @n33co
License: Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)

Bludit dependencies:
- Site title
- Site description
- User profile, first name, last name and profile picture