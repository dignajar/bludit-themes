<section id="plugins">
<div div class="plugin-box'>

<!-- Plugins Sidebar -->
<?php Theme::plugins('siteSidebar') ?>

</div></section>